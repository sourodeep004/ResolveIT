
import { ShieldCheck } from 'lucide-react';
import Sidebar from './Sidebar.jsx';

export default function Layout({
  user,
  page,
  setPage,
  ticketCount,
  onLogout,
  canViewAnalytics,
  children
}) {
  const initials = (user?.name || 'User')
    .trim()
    .split(/\s+/)
    .map(part => part[0])
    .slice(0, 2)
    .join('')
    .toUpperCase();

  return (
    <div className="app-layout">
      <Sidebar
        user={user}
        page={page}
        setPage={setPage}
        ticketCount={ticketCount}
        onLogout={onLogout}
        canViewAnalytics={canViewAnalytics}
      />

      <main className="main-area">
        <header className="topbar">
          <div className="breadcrumb">
            <span>Workspace</span>
            <span className="breadcrumb-separator">/</span>
            <b>{page}</b>
          </div>

          <div className="top-actions">
            <span className="system-status">
              <i className="system-status-dot" />
              <span>All systems operational</span>
            </span>

            <span className="topbar-divider" />

            <div className="topbar-user">
              <div className="topbar-user-copy">
                <b>{user?.name || 'User'}</b>
                <span>{user?.role || 'Employee'}</span>
              </div>
              <div className="avatar top-avatar">{initials}</div>
            </div>
          </div>
        </header>

        <div className="content">
          {children}

          <footer className="app-footer">
            <span>© 2026 ResolveIT</span>
            <span>Built for reliable IT service delivery</span>
          </footer>
        </div>
      </main>
    </div>
  );
}
