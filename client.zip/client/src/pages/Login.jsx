
import { useState } from 'react';
import { Link } from 'react-router-dom';
import { ShieldCheck } from 'lucide-react';
import { api } from '../lib/api.js';

export default function Login({ onLogin }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  async function submit(event) {
    event.preventDefault();
    setBusy(true);
    setError('');

    try {
      const { data } = await api.post('/auth/login', { email, password });
      onLogin(data);
    } catch (err) {
      setError(err.response?.data?.message || 'Could not sign in. Check the server.');
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="login-wrap">
      <section className="login-card">
        <div className="brand-mark"><ShieldCheck size={25} /></div>
        <p className="eyebrow">RESOLVEIT SERVICE DESK</p>
        <h1>Welcome back.</h1>
        <p className="muted">Sign in to manage your IT service requests.</p>

        {error && <div className="error-box">{error}</div>}

        <form onSubmit={submit} className="stack">
          <label>
            Email address
            <input
              type="email"
              autoComplete="email"
              value={email}
              onChange={event => setEmail(event.target.value)}
              required
              placeholder="you@company.com"
            />
          </label>

          <label>
            Password
            <input
              type="password"
              autoComplete="current-password"
              value={password}
              onChange={event => setPassword(event.target.value)}
              required
            />
          </label>

          <button className="primary-btn" disabled={busy}>
            {busy ? 'Signing in…' : 'Sign in'} <span>→</span>
          </button>
        </form>

        <p className="small muted">
          New to ResolveIT? <Link to="/register">Create an employee account</Link>
        </p>
      </section>
    </main>
  );
}
