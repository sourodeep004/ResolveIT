
import { useState } from 'react';
import { Link } from 'react-router-dom';
import { ShieldCheck } from 'lucide-react';
import { api } from '../lib/api.js';

export default function Register({ onLogin }) {
  const [form, setForm] = useState({
    name: '',
    email: '',
    password: '',
    department: 'General'
  });
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  function change(event) {
    setForm(previous => ({
      ...previous,
      [event.target.name]: event.target.value
    }));
  }

  async function submit(event) {
    event.preventDefault();
    setBusy(true);
    setError('');

    try {
      const { data } = await api.post('/auth/register', form);
      onLogin(data);
    } catch (err) {
      setError(err.response?.data?.message || 'Registration failed.');
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="login-wrap">
      <section className="login-card">
        <div className="brand-mark"><ShieldCheck size={25} /></div>
        <p className="eyebrow">GET STARTED</p>
        <h1>Create your account.</h1>
        <p className="muted">Employee accounts are created with standard access.</p>

        {error && <div className="error-box">{error}</div>}

        <form onSubmit={submit} className="stack">
          <label>
            Full name
            <input name="name" value={form.name} onChange={change} minLength={2} required />
          </label>

          <label>
            Work email
            <input name="email" type="email" value={form.email} onChange={change} required />
          </label>

          <label>
            Department
            <input name="department" value={form.department} onChange={change} />
          </label>

          <label>
            Password
            <input
              name="password"
              type="password"
              value={form.password}
              onChange={change}
              minLength={8}
              required
            />
          </label>

          <button className="primary-btn" disabled={busy}>
            {busy ? 'Creating account…' : 'Create account'} <span>→</span>
          </button>
        </form>

        <p className="small muted">
          Already registered? <Link to="/login">Sign in</Link>
        </p>
      </section>
    </main>
  );
}
